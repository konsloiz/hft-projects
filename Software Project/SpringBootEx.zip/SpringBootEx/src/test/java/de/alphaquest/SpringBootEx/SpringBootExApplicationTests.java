package de.alphaquest.SpringBootEx;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootExApplicationTests {

	@Test
	void contextLoads() {
	}

}
